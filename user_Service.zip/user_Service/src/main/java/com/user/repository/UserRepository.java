package com.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.user.model.UserModel;

@Repository
public interface UserRepository extends JpaRepository<UserModel, String> {
   
	@Modifying
	@Query("UPDATE UserModel p SET p.isDeleted  = 'Y' WHERE p.user_Id = :user_Id") 
	void updateDeleteFlag(@Param("user_Id") String user_Id);
	
	@Override
	@Query("SELECT p FROM UserModel p WHERE isDeleted='N'")
	public List<UserModel> findAll();
	
	@Override
	@Query("SELECT p FROM UserModel p WHERE p.user_Id = :user_Id and isDeleted='N'")
	public UserModel findOne(@Param("user_Id") String user_Id);

}
