package com.user.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.user.model.UserModelDetails;
import com.user.service.UserService;



@RestController
public class UserController {
	
	@Autowired
	UserService service;
	
	@PostMapping("/save")
	public void createUsers(@RequestBody UserModelDetails details)
	{
		service.createUser(details);
	}
	
	@GetMapping(value="/get",headers="Accept=application/json")
	public List<UserModelDetails> getAllUser()
	{
		List<UserModelDetails> user=service.getUser();
		return user;
	}
	
	@GetMapping(value="/userId/{user_Id}", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserModelDetails> getUserById(@PathVariable("user_Id") String user_Id)
	{
		System.out.println("Fetching user by userId " + user_Id);
		UserModelDetails details=service.findById(user_Id);
		if(details==null){
			return new ResponseEntity<UserModelDetails>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<UserModelDetails>(details,HttpStatus.OK);
	}
	
	@PutMapping("/delete/{user_Id}")
	public String delete(@PathVariable("user_Id") String user_Id){
		service.deleteUserById(user_Id);
		return "User Deleted";
		
	}

}
