package com.user.service;

import java.util.List;

import com.user.model.UserModelDetails;

public interface UserService {

	public void createUser(UserModelDetails userDetails);

	public List<UserModelDetails> getUser();

	public void deleteUserById(String user_Id);

	public UserModelDetails updateUser(UserModelDetails userDetails,String l);
	
	public UserModelDetails findById(String user_Id);

}
