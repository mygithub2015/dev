package com.user.model;

public class UserModelDetails {

	private String user_Id;
	private String user_Password;
	private String user_Name;
	private String user_Email;
	private String user_Mobile;
	private String user_Role;
	
	public UserModelDetails() {
	}

	public UserModelDetails(String user_Id, String user_Password, String user_Name, String user_Email,
			String user_Mobile, String user_Role) {
		super();
		this.user_Id = user_Id;
		this.user_Password = user_Password;
		this.user_Name = user_Name;
		this.user_Email = user_Email;
		this.user_Mobile = user_Mobile;
		this.user_Role = user_Role;
	}

	public String getUser_Id() {
		return user_Id;
	}

	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}

	public String getUser_Password() {
		return user_Password;
	}

	public void setUser_Password(String user_Password) {
		this.user_Password = user_Password;
	}

	public String getUser_Name() {
		return user_Name;
	}

	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}

	public String getUser_Email() {
		return user_Email;
	}

	public void setUser_Email(String user_Email) {
		this.user_Email = user_Email;
	}

	public String getUser_Mobile() {
		return user_Mobile;
	}

	public void setUser_Mobile(String user_Mobile) {
		this.user_Mobile = user_Mobile;
	}

	public String getUser_Role() {
		return user_Role;
	}

	public void setUser_Role(String user_Role) {
		this.user_Role = user_Role;
	}

}
