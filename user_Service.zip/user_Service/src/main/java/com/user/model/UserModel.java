package com.user.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "userModel")
public class UserModel {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "UserId")
	private String user_Id;
	
    @NotNull
	@Column(name = "UserPassword")
	private String user_Password;
    
    @NotNull(message="name must not be blank!")
    @Size(min=3, max=20)
	@Column(name = "UserName")
	private String user_Name;
    
    @Email
	@Column(name = "UserEmail")
	private String user_Email;
    
    @NotEmpty
	@Column(name = "UserMobile")
	private String user_Mobile;

    @NotNull
	@Column(name = "UserRole")
	private String user_Role;
	@JsonIgnore
	@Column(name="IsDeleted" , columnDefinition="Varchar2(5) default 'N'")
	private String isDeleted;

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public UserModel() {

	}

	public UserModel(String user_Id, String user_Password, String user_Name, String user_Email, String user_Mobile,
			String user_Role,String isDeleted) {
		super();
		this.user_Id = user_Id;
		this.user_Password = user_Password;
		this.user_Name = user_Name;
		this.user_Email = user_Email;
		this.user_Mobile = user_Mobile;
		this.user_Role = user_Role;
		this.isDeleted= isDeleted;
	}

	public String getUser_Id() {
		return user_Id;
	}

	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}

	public String getUser_Password() {
		return user_Password;
	}

	public void setUser_Password(String user_Password) {
		this.user_Password = user_Password;
	}

	public String getUser_Name() {
		return user_Name;
	}

	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}

	public String getUser_Email() {
		return user_Email;
	}

	public void setUser_Email(String user_Email) {
		this.user_Email = user_Email;
	}

	public String getUser_Mobile() {
		return user_Mobile;
	}

	public void setUser_Mobile(String user_Mobile) {
		this.user_Mobile = user_Mobile;
	}

	public String getUser_Role() {
		return user_Role;
	}

	public void setUser_Role(String user_Role) {
		this.user_Role = user_Role;
	}

	@Override
	public String toString() {
		return "UserModel [user_Id=" + user_Id + ", user_Password=" + user_Password + ", user_Name=" + user_Name
				+ ", user_Email=" + user_Email + ", user_Mobile=" + user_Mobile + ", user_Role=" + user_Role
				+ ", isDeleted=" + isDeleted + "]";
	}


}
